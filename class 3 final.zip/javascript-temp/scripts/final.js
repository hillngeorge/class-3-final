let result = document.getElementById("result");



function convertTemperatureRange(startValue, endValue, scale) {
    for (let temperature = startValue; temperature <= endValue; temperature++) {
        if (scale === "C" || scale === "c") {
            let convertedTemperature = (temperature * 9/5) + 32;
            let resultMsg = `${temperature} Celsius is ${convertedTemperature.toFixed(2)} Fahrenheit`;
            result.innerHTML = resultMsg;
            10
        } else if (scale === "F" || scale === "f") {
            let convertedTemperature = (temperature - 32) * 5/9;
            console.log(`${temperature} Fahrenheit is ${convertedTemperature.toFixed(2)} Celsius`);
        }
    }
}

// Get user inputs
let startTemperature = parseFloat(prompt("Enter starting temperature: "));
let endTemperature = parseFloat(prompt("Enter ending temperature: "));
let temperatureScale = prompt("Enter temperature scale (C or F):");

// Call the function with user inputs
convertTemperatureRange(startTemperature, endTemperature, temperatureScale);
