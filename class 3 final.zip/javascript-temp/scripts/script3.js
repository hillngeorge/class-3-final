let userName="Samantha";

if(userName=="Fernanda"){
console.log("welcome to the system");
}
else{
    console.log("incorrect user name");
}
let num=10
if(10==10){
    console.log("The Value is the same");
}

if(num>=100){
    console.log("the value is less than 100");
}

if(num>=100){
    console.log("the value is greater than 100");
}

if(10==10){
    console.log("same value and same datatype");
}

if("10"==10){
    console.log("same value");
}