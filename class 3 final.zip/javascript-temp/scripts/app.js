function celtoFax(){
    let temperature=prompt("Enter your temperature:");
    let fehrenheit =(temperature * 9/5) + 32;
    document.getElementById("temp").innerHTML=fehrenheit;
}